var express = require('express');
var router = express.Router();
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');



const data = [
  {
    Fname: 'Djofang ',
    department: 'production manager',
  },
  {
    Fname: 'Ramsey Asmah',
    department: 'supervisor '
  },
  {
    Fname: 'Obinim agyepong',
    department: 'Sales executive',
  },
  {
    Fname: 'Fella Kuti',
    department: 'Marketing',
  }
]


/* GET Staffs page.*/
router.get('/', function(req, res) {

  const url = 'mongodb://localhost:27017';
  const dbName = 'employeedb';

(async function() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log("Connected correctly to server");

    const db = client.db(dbName);

    /* Insert multiple documents*/
    let r;
    r = await db.collection('workers').insertMany(data);
    assert.equal(data.length, r.insertedCount);

    const employeeList = await db.collection('workers').find().toArray()
    res.render('workersList', { title: 'workers', employeeList });
  } catch (err) {
    console.log(err.stack);
  }
  await client.db(dbName).dropDatabase();
  /* Close connections*/
  client.close();
})();
    
    
 
});

module.exports = router;
